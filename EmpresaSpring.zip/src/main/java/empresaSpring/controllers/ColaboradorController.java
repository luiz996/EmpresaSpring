package empresaSpring.controllers;

import empresaSpring.entities.Colaborador;
import empresaSpring.dto.ColaboradorDTO;
import empresaSpring.services.ColaboradorService;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/colaboradores")
public class ColaboradorController {

    private final ColaboradorService service;

    public ColaboradorController(ColaboradorService service) { this.service = service; }

    @GetMapping
    public List<ColaboradorDTO> findAll() {
        return service.findAll().stream().map(this::toDTO).collect(Collectors.toList());
    }

    @GetMapping("/{id}")
    public ColaboradorDTO findById(@PathVariable Long id) {
        return service.findById(id).map(this::toDTO).orElse(null);
    }

    @PostMapping
    public ColaboradorDTO create(@RequestBody Colaborador colaborador) {
        return toDTO(service.save(colaborador));
    }

    @PutMapping("/{id}")
    public ColaboradorDTO update(@PathVariable Long id, @RequestBody Colaborador colaborador) {
        colaborador.setId(id);
        return toDTO(service.save(colaborador));
    }

    @DeleteMapping("/{id}")
    public void delete(@PathVariable Long id) { service.delete(id); }

    private ColaboradorDTO toDTO(Colaborador c) {
        ColaboradorDTO dto = new ColaboradorDTO();
        dto.setId(c.getId());
        dto.setNome(c.getNome());
        dto.setCargoNome(c.getCargo() != null ? c.getCargo().getNome() : null);
        return dto;
    }
}