package empresaSpring.config;

import empresaSpring.entities.Setor;
import empresaSpring.entities.Cargo;
import empresaSpring.entities.Colaborador;
import empresaSpring.repositories.SetorRepository;
import empresaSpring.repositories.CargoRepository;
import empresaSpring.repositories.ColaboradorRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Configuration;

@Configuration
public class TestConfig implements CommandLineRunner {

    private final SetorRepository setorRepo;
    private final CargoRepository cargoRepo;
    private final ColaboradorRepository colaboradorRepo;

    public TestConfig(SetorRepository setorRepo, CargoRepository cargoRepo, ColaboradorRepository colaboradorRepo) {
        this.setorRepo = setorRepo;
        this.cargoRepo = cargoRepo;
        this.colaboradorRepo = colaboradorRepo;
    }

    @Override
    public void run(String... args) throws Exception {
        Setor setor1 = new Setor();
        setor1.setNome("Vendas");
        setorRepo.save(setor1);

        Cargo cargo1 = new Cargo();
        cargo1.setNome("Gerente");
        cargo1.setSetor(setor1);
        cargoRepo.save(cargo1);

        Colaborador col1 = new Colaborador();
        col1.setNome("João");
        col1.setCargo(cargo1);
        colaboradorRepo.save(col1);
    }
}