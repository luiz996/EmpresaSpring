package empresaSpring.services;

import empresaSpring.entities.Colaborador;
import empresaSpring.repositories.ColaboradorRepository;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

@Service
public class ColaboradorService {

    private final ColaboradorRepository repository;

    public ColaboradorService(ColaboradorRepository repository) { this.repository = repository; }

    public List<Colaborador> findAll() { return repository.findAll(); }
    public Optional<Colaborador> findById(Long id) { return repository.findById(id); }
    public Colaborador save(Colaborador colaborador) { return repository.save(colaborador); }
    public void delete(Long id) { repository.deleteById(id); }
}